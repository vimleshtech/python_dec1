'''
===============
Anonomys function / lambda    
Multi threading
Networking
=================
Anonomys function / lambda

'''

'''
def getnum(n):
    return lambda  n:n+1


d = getnum(1)
print(d)
'''
data = lambda m : m + 10

def x(m):
    m = m+10
    return m
print(data(1))

print(data(10))

print(x(1))



def myfunc(n):
  return lambda a : a * n

a = myfunc(2)
print(a(4))

















