'''
===================
Dict
Anonomys function / lambda
Multi threading
Networking

=================
Dict

'''

holidays = {"0126":'republic day','0310':'holi',1:'100'}



print(holidays)
print(holidays['0310'])
print(holidays[1])


k = input('enter date (mmdd) :')
print(holidays[k])






