'''
Multi threading
    thread: is process or task
    multi threading: multiple process
    
Networking
=================
'''

import time
import threading

def p1():
    for x in range(1,5):
        print(x)
        #time.sleep(2)
        
def p2():
    for x in range(11,15):
        print(x)
        #time.sleep(2)


#p1()
#p2()
t1 = threading.Thread(target=p1,name="job1")
t2 = threading.Thread(target=p2,name="job2")
t1.start()
t2.start()












