'''
==================
Tuple
Dict
Anonomys function / lambda
Multi threading
Networking

=================
'''
t  = ("monday","tuesday",'wednesday','thursday','friday')

print(len(t))
print(t[0])      

day = input('enter day , on which date you want apply for leave ')

if day in t:
    eid = input('enter eid :')
    #....
    #..

else:
    print('you cannot apply for leave, this is off day')
    
                
