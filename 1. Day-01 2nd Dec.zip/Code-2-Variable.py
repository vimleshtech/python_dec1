#int
a =1
print(a)
print(type(a)) 

#float
a =3333.232
print(type(a))

#str
a ='ffdd11'
print(type(a))
a ="ffdd11"
print(type(a))

#bool
b = True
print(type(b))

#list
l =[111,222,333,44,'fjhsgs']
print(type(l))

#tuple
t =(111,22,3,3)
print(type(t))

#dict
d ={'a':'alpha','b':'beta',1:'one'}
print(type(d))


#set
s ={'iphone','dove','iphone'}
print(type(s))

















