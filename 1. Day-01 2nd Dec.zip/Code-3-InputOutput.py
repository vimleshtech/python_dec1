a = input('enter data ')
b = input('enter data ')

print(type(a))
print(type(b))

#type casting
a =int(a)
b =int(b)

c =a+b
print('sum of two numebrs : ',end='\t')
print(c)




