sales_amt = int(input('enter amt :'))

tax = 0
#if condition 
if sales_amt>1000:
     tax = sales_amt *.18

total_sale = tax+ sales_amt
print('total amount = ',total_sale)

## if else
tax = 0
#if condition 
if sales_amt>1000:
     tax = sales_amt *.18
else:
     tax = sales_amt *.05
     
total_sale = tax+ sales_amt
print('total amount = ',total_sale)

### if else condition : print grade card
hs = int(input('enter mark in hindi :'))
es = int(input('enter mark in eng :'))
cs = int(input('enter mark in computer :'))
ms = int(input('enter mark in math :'))

total = hs+es+cs+ms
avg  = total/4
print(total)
print(avg)

if avg>=80:
     print('A')
elif avg>=60:
     print('B')
elif avg>=40:
     print('D')
else:
     print('F')
     



     















     
