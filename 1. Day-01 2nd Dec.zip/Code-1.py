sid = 101
name ="Raman"

if sid == 101:
      print(1)
      print(1)
      print(1)
      print(1)



 


#print(sid)
'''
print(name)
print(name)
print(name)

'''


