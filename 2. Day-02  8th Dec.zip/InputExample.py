
hs = input('enter score in hindi : \n')
es = input('enter score in english :')
cs = input('enter score in computer :')
ms = input('enter score in maths :')


total = int(hs) + int(es) + int(cs) + int(ms)
avg = total/4

print(total)
print(avg)

if avg>=80:
     print('A')
     print('test')
if avg>=60 and avg<80:
     print('B')
elif avg >=40:
     print('C')
else:
     print('F')
     
     






