name = "ram shyam"#input('enter name :')

a=5
a=10

print(name.upper())
print(name.lower())
print(len(name))
print(name.title())
print(name.strip())
print(name.replace('a','x'))

o = list(name)
s=''
for w in o:
     s+=w
     print(s)
     

if name.endswith('n'):
     print('end with n')

if name.startswith('ra'):
     s =name.split(' ')
     print(s[0],' start with ra')



#slicer
print(name[2:5])

     



