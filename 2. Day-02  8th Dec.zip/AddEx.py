a =11
b =433

c =a+b

name ='raman sinha'

print('sum of two numbers :',c,name)


# show greater no

'''

if a>b:
     print('a is greater')

else:
     print('b is greater')
     

'''
