# My First Python Code
n = input('enter name : ')
a = input('enter age :')


print('My name is  ',n)
print('My age is ',a)



