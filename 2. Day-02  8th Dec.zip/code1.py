a =1
b =444
c =a*b
print(c)
