for x in range(1,11): # from 1 to 10 , default increment is 1
     print(x)

#print odd numebrs 
for x in range(1,11,2): # from 1 to 10 
     print(x)


#print in reverse
for x in range(10,0,-1): #  from 10 to >0 
     print(x)

