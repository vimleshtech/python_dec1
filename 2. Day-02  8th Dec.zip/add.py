## input
# here input is a function which read data from user/console
#default data type is string in python 3.0+ version

a = input('enter data :')
b = input('enter data :')
d = input('enter data :')


#type casting : convert str to int
a = int(a)
b = int(b)
d = int(d)

# expression or addition
c=a+b

#print 
print(c)

##
if a>b and a>d:
     print('a is greater')
elif b>a and b>d:
     print('b is greater')
else:
     print('d is greater')
     


     




