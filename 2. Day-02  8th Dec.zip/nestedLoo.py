for x in range(1,11): # from 1 to 10 , default increment is 1
     print(x,end='') # end ='' don't change the line


print() # change line 

'''
r=1 c =123
r=2 c =123
r=3 c =123
r=4 c =123
'''
# nested loop
for r in range(1,5): # from 1 to 4  # row 
     for c in range(1,4):  # from 1 to 3  #col
          print(c,end='')
     print()
          

#pattern
for r in range(1,4): # from 1 to 4  # row 
     for c in range(1,4):  # from 1 to 3  #col
          print('*',end='')
     print()
          
     
##
for r in range(1,10): # from 1 to 4  # row 
     for c in range(1,r+1):  # from 1 to 3  #col
          print('*',end='')
     print()


##
for r in range(1,10): # from 1 to 4  # row 
     for c in range(r,10):  # from 1 to 3  #col
          print('*',end='')
     print()



     

     
