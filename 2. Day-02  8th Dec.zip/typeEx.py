a =1
print(type(a))

b =444.2
print(type(b))

c ='sjsghs'
print(type(c))

d ="skhsjhsghs"
print(type(d))

l =[1111,2222,333,4,'shsghss']
print(type(l))


t =(1111,22,3,'sjsgghs')
print(type(t))


x ={'a':'alpha','x':'beta',1:'one'}
print(type(x))


y ={'iphone','mac','iphone'}
print(type(y))
print(y)





