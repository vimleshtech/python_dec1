for i in range(1,10,2):
     print('(',end='')
     for j in range(1,i+1,2):
          if j<i:
               print(j,end='+')
          else:
               print(j,end='')

     print(')',end='')


     
          
     
