i = 0
#break 
while i<=10:

     i=i+1
     if i % 3 ==0:
          break

     print(i)
     

     
     
i = 0 #assignment operator 
#continue
while i<=10:

     i=i+1
     if i % 3 ==0:  # comparision operator 
          continue

     print(i)
