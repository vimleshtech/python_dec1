# while example
i =1 # init /start from

while i<=100:  # condition / limit
     print(i)
     i = i+1  # increment


# print in reverse order
i =100  # init 
while i>0:  # condition 
     print(i)
     i -= 1  # decrement


#print all odd numbers from 1 to 30
i =1
while i<30:
     print(i)
     i=i+2

#wap to get sum or all even and odd numbers betwen two given range
a = int(input('enter data :'))
b = int(input('enter data :'))

se=0
so=0

while a<=b:# codition 
     if a % 2 ==0:   # check even no .
          se =se+a
     else:  
          so = so+b

     a=a+1

print('sum of all even numbers :',se)
print('sum of all odd numbers :',so)


#print table of given no
i =1
while i<=10:
     #print(5*i)
     print(5,'*',i,5*i)
     i =i+1
     

          









     
