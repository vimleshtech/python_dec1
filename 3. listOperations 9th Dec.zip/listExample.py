data = []# emtpy list
print(type(data))

data = [1111,2222,333,'dfjhd']  # list with data 
print(data) # show all data

#read particular value / 1st value
#list index start from 0 index
print(data[0])

#print all element one after another
for x in data:
     print(x)

#or
for i in range(0,4):
     print(data[i])
     
     
#two dimenssion
a = [[1, 2, 3],[ 11, 22, 33]]
print(a) #show all
print(a[0])  # print first row
print(a[0][0],a[1][2]) # first row and first col value


#read all elements 
for r in a:
     for c in r:
          print(c)  
     

      

