data =[111,2222,333,4]
print(len(data))

data.append(100)
print(data)

print(max(data))
print(min(data))
print(sum(data))


data.pop()
print(data)


data.insert(2,345)
print(data)

data.remove(333)
print(data)


data.sort()
print(data)

print(data[0]) # first
print(data[-1])  # last element
print(data[0:3]) # from 0 to 2
print(data[:3]) # from 0 to 2

data =[1,2,3,4]
print(data[:-1])  #first data to last-1 1 2 3
print(data[:3])  #first data to last-1 1 2 3

#-1 : read index from right by -1 (decrementer)
# :: : read -1 to 0 
print(data[::-1]) #show in reverse order


#replace
data[1] =3333

for i in range(0,len(data)): #(0,4)
     if data[i] ==1:
          data[i]=2
               
#clear
data=[]
data.clear()

a='dhghdfd'
print(len(a))


a =1
b ='sjhsjhsg'
c =str(a)  +   b
print(c)

a='1'
b='32'



















