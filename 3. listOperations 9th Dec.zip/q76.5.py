for i in range(1,10):
     print('(',end='')
     for c in range(1,i+1):
          if c <i:
               print(c,end='+')
          else:
               print(c,end='')
     print(')+',end='')
     
#
print()
s =0
for i in range(1,10):     
     for c in range(1,i+1):
          s =s+c

print(s)

     
